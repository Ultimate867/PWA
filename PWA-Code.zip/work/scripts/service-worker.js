self.addEventListener('activate', function(e) {
  console.log('[ServiceWorker] Activate');
});